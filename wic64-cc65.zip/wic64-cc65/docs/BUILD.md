cl65 -t c64 wic64utils.c wic64api.c examples/get_demo.c wic64lib.lib -o get_demo.prg
cl65 -t c64 wic64utils.c wic64api.c examples/post_demo.c wic64lib.lib -o post_demo.prg
cl65 -t c64 wic64utils.c wic64api.c examples/load_demo.c wic64lib.lib -o load_demo.prg
